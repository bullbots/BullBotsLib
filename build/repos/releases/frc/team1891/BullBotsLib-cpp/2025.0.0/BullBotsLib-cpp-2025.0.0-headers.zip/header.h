#pragma once

void func();
